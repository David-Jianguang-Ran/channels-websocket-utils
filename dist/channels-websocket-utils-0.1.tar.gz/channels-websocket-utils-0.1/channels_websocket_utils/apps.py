from django.apps import AppConfig


class ChannelsWebsocketUitlsConfig(AppConfig):
    name            = 'channels_websocket_utils'
    verbose_name    = "Channels Websocket Utils"
